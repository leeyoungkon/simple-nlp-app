package org.openpaas.paasta.portal.api.two.Entity;


import javax.persistence.*;


/**
 * Entity
 * 해당 클래스가 엔티티임을 알리기 위해 사용한다. 애플리케이션이 실행이 될 때 엔티티 자동검색을 통하여 이 어노테이션이 선언 된 클래스들은 엔티티 빈으로 등록한다.
 *
 * Table
 * 데이터 저장소인 테이블을 의미하며, name 값은 실제 데이터베이스의 테이블명이고, 생략하면 클레스의 이름을 테이블의 이름으로 자동 인식한다.
 */
@Entity
@Table(name = "book")
public class Book {

    /**
     * Id
     * 엔티티빈의 기본키를 의미하며, 하나의 엔티티에는 반드시 존재해야 한다.
     *
     * Column
     * 필드와 테이블의 컬럼을 매핑시켜준다. 생략이 가능하며, 생략시 필드의 이름이 테이블의 컬럼으로 자동으로 매핑이된다.
     */
    @Id
    @Column(name = "bookId", nullable = false)
    private int bookId;

    @Column(name = "bookName", nullable = false)
    private String bookName;

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

    
    
}
