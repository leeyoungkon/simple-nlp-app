package com.sict.app.dao;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sict.app.dto.Book;


@Repository
public class BookDaoImpl implements BookDao {

@Autowired
    private JdbcTemplate jdbcTemplate; 
    
    StringBuffer query;

	@Override
	public Book getBookInfo(int id) {
		return (Book) jdbcTemplate.queryForObject("SELECT * FROM book WHERE bookId = ?",
		new Object[] {id}, new BeanPropertyRowMapper<>(Book.class));  
	} 
	
	@Override
	public ArrayList<Book> getBookList() {
	     query = new StringBuffer();    
	     query.append("SELECT * from book");
	    
	        return (ArrayList<Book>) jdbcTemplate.query(query.toString(), 
	                new Object[]{}, new BeanPropertyRowMapper<Book>(Book.class));
	 }
	 
	 @Override
	 public int insertBook(Book book) {
	        return jdbcTemplate.update("INSERT INTO book VALUES( ?, ?)",
	                book.getBookId(), book.getBookName());
	 }		    
	   
	 @Override
	 public int updateBook(Book book) {
	        return jdbcTemplate.update("UPDATE book SET bookname=? WHERE bookId=?",
	                book.getBookName(), book.getBookId());
	 }
	       
	 @Override 
	 public int deleteBook(int bookId) {
	        return jdbcTemplate.update("DELETE FROM book WHERE bookId = ?", bookId);
	 }

}
