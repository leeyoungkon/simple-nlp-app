package com.sict.app.dao;

import java.util.ArrayList;

import com.sict.app.dto.Book;


public interface BookDao {
	public Book getBookInfo(int id);
	public ArrayList<Book> getBookList();
	public int insertBook(Book book);
	int updateBook(Book book);
	int deleteBook(int bookId);

}
