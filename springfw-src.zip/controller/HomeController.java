package com.sict.app.controller;


import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sict.app.dao.BookDao;
import com.sict.app.dto.Book;
import com.sict.app.service.BookService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	private BookService bookService;
	
	@Autowired
	private BookDao bookDao; 
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String getBook(@RequestParam("id") int id, Model model) {
			
		Book book = bookService.getBookInfo(id);
		model.addAttribute("book", book); 
		
		return "getBook";
	}
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String deleteBook(@RequestParam("id") int id, Model model) {
				
		int count = bookService.deleteBook(id);
		model.addAttribute("count", count); 
		
		return "deleteBook";
	}
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(Model model) {
		ArrayList<Book> books = bookDao.getBookList();
		model.addAttribute("books", books);
		return "list";
	}

	@RequestMapping(value="/bookForm")
	public String bookForm() {		
		return "bookForm"; 
	}
	@RequestMapping(value="/book")
	public ModelAndView insertBook(Book book) {
		ModelAndView view = new ModelAndView();
		bookService.insertBook(book);
		view.addObject("BK", book);
		view.setViewName("book");
		return view; 
	}
	

	
}
