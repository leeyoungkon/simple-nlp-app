package com.sict.app.service;

import java.util.ArrayList;

import com.sict.app.dto.Book;

public interface BookService {
	public Book getBookInfo(int id); 
	public ArrayList<Book> getBookList();
	public int insertBook(Book book);
	public int deleteBook(int id);
	public int updateBook(Book book);
}
