package com.sict.app.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sict.app.dao.BookDao;
import com.sict.app.dto.Book;


@Service("bookService")
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDao bookDao;
	
	@Override
	public Book getBookInfo(int id) {
		// TODO Auto-generated method stub
		return bookDao.getBookInfo(id);
	}
	@Override
	public ArrayList<Book> getBookList() {
		// TODO Auto-generated method stub
		return bookDao.getBookList();
	}
	@Override
	public int updateBook(Book book) {
		// TODO Auto-generated method stub
		return bookDao.updateBook(book);
	}
	@Override
	public int deleteBook(int id) {
		// TODO Auto-generated method stub
		return bookDao.deleteBook(id);
	}
	@Override
	public int insertBook(Book book) {
		// TODO Auto-generated method stub
		return bookDao.insertBook(book);
	}

}
